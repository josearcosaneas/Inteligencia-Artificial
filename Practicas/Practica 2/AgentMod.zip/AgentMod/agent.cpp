#include "agent.h"
#include "environment.h"
#include "state.h"
#include <cstdlib>
#include <iostream>
#include <list>
#include <queue>


using namespace std;


// -----------------------------------------------------------
Environment::ActionType Agent::AgenteReactivo()
{
 	if (dirty_) return Environment::actSUCK;
	else return static_cast<Environment::ActionType> (rand()%4);

}





// -----------------------------------------------------------
// Inserta un estado (st) en una lista de estados (lista) y devuelve un iterador a su posici�n en la lista (it)
// La funci�n devuelve "true" e inserta el estado (st) al final de la lista si es estado no estaba ya en la lista.
// La funci�n devuelve "false" si el estado (st) ya estaba en la lista, y NO LO INSERTA EN LA LISTA
// -----------------------------------------------------------
bool InsertarLista(list <state> &lista, const state &st, list<state>::iterator &it){
  char ch;
  it= lista.begin();
  bool salida=false;
  while (it!=lista.end() and !(*it==st) )
    it++;
  if (it==lista.end()){
    lista.push_back(st);
    it = lista.end();
    it--;
    salida=true;
  }
  return salida;
}



// -----------------------------------------------------------
// Esto sirve para declarar un m�todo de ordenaci�n para la cola con prioridad.
// En esto caso, los ordena de menor a mayor en el primer valor del par (double,iterador)
// -----------------------------------------------------------
struct Comparar{
bool operator() (const pair<double,list<state>::iterator > &a, const pair<double,list<state>::iterator > &b){
  return (a.first > b.first );
}
};

// -----------------------------------------------------------
// Busqueda en Anchura
// -----------------------------------------------------------
Plan Agent::Busqueda_Anchura(state start){
  Plan plan;
  typedef pair<double,list<state>::iterator > elemento_cola;

  int last_level=0; // Indica el nivel del grafo por donde va la b�squeda
  int estados_evaluados = 0; // Indica el n�mero de nodos evaluados
  state aux = start; // start es el estado inicial
  state sigActions[6], mejor_solucion; // para almacenar las siguientes acciones y la mejor soluci�n
  int n_act;

  list<state> lista;               // Lista que almacenara todos los estados
  list<state>::iterator p, padre;  // Declara dos iteradores a la lista
  priority_queue <elemento_cola, vector<elemento_cola>, Comparar > cola; //Declaraci�n de la cola con prioridad

  elemento_cola siguiente; // Declara una variable del tipo almacenado en la cola con prioridad

  InsertarLista(lista,aux,padre); // Inserta el estado inicial en la lista y (padre) es un iterador a su posici�n.

  while (!aux.Is_Solution()){
      // Indica si ha incrementado el nivel del grafo por donde est� buscando
      if (aux.Get_g()!=last_level){
        cout << "Level " << aux.Get_g() << endl;
        last_level = aux.Get_g();
      }

      estados_evaluados++; // Incremento del n�mero de estados evaluados

      n_act=aux.Generate_New_States(sigActions); // Genera los nuevos estados a partir del estado (aux)

      // Para cada estado generado, pone un enlace al estado que lo genero,
      // lo inserta en la lista, y si no estaba ya en dicha lista, lo incluye en la cola con prioridad.
      // El valor de prioridad en la lista lo da el m�todo "Get_g()" que indica la energ�a consumida en dicho estado.
      for (int i=0; i<n_act; i++){
          sigActions[i].Put_Padre(padre);
          if (InsertarLista(lista, sigActions[i], p) ){
            double value = sigActions[i].Get_g();
            cola.push( pair<double,list<state>::iterator > (value,p) );
         }
      }

      // Saca el siguiente estado de la cola con prioridad.
      padre = cola.top().second;
      aux = *padre;
      cola.pop();
  }

  // Llegados aqu� ha encontrado un estado soluci�n, e
  // incluye la soluci�n en una variable de tipo plan.
  plan.AnadirPlan(aux.Copy_Road(), lista.size(), estados_evaluados );

  return plan; // Devuelve el plan
}



// -----------------------------------------------------------
Plan Agent::Busqueda_Profundidad(state start){
  Plan plan;
  state aux = start;
  int estados_evaluados = 0;


  // IMPLEMENTA AQU� LA BUSQUEDA EN PROFUNDIDAD

  //plan.AnadirPlan(aux.Copy_Road(), lista.size(), estados_evaluados );

 return plan;
}




// -----------------------------------------------------------
// --------------------- Busqueda Heuristica -----------------
// -----------------------------------------------------------

double Heuristica(const state &estado){
  // Suciedad que queda pendiente en la habitacion
  return estado.Get_Pending_Dirty();
}


// -----------------------------------------------------------


Plan Agent::Escalada(state start){
  Plan plan;
  state aux = start;
  int estados_expandidos=0, estados_evaluados=0;

  // IMPLEMENTA AQU� EL M�TODO DE ESCALADA

  plan.AnadirPlan(aux.Copy_Road(), estados_expandidos, estados_evaluados );

  return plan;
}



// -----------------------------------------------------------
Plan Agent::Think(const Environment &env, int option){
  state start(env);
  Plan plan;


  switch (option){
      case 0: //Agente Reactivo

              break;
      case 1: //Busqueda Anchura
              plan = Busqueda_Anchura(start);
              cout << "\n Longitud del Plan: " << plan.Get_Longitud_Plan() << endl;
              plan.Pinta_Plan();
              break;
      case 2: //Busqueda Profundidad
              plan = Busqueda_Profundidad(start);
              cout << "\n Longitud del Plan: " << plan.Get_Longitud_Plan() << endl;
              plan.Pinta_Plan();
              break;
      case 3: //Busqueda Profundidad
              plan = Escalada(start);
              cout << "\n Longitud del Plan: " << plan.Get_Longitud_Plan() << endl;
              plan.Pinta_Plan();
              break;

  }

  return plan;
}






// -----------------------------------------------------------
void Agent::Perceive(const Environment &env)
{
	bump_ = env.isJustBump();
	dirty_ = env.isCurrentPosDirty();
}
// -----------------------------------------------------------
string ActionStr(Environment::ActionType action)
{
	switch (action)
	{
	case Environment::actUP: return "UP";
	case Environment::actDOWN: return "DOWN";
	case Environment::actLEFT: return "LEFT";
	case Environment::actRIGHT: return "RIGHT";
	case Environment::actSUCK: return "SUCK";
	case Environment::actIDLE: return "IDLE";
	default: return "???";
	}
}
